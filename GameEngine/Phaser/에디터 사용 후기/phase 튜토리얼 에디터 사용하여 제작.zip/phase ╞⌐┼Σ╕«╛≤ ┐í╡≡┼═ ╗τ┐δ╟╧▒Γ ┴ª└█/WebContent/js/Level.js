/**
 * Level state.
 */
function Level() {
	Phaser.State.call(this);
	// TODO: generated method.
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State.prototype);
Level.prototype = proto;
Level.prototype.constructor = Level;

Level.prototype.create = function() {
	 this.game.physics.startSystem(Phaser.Physics.ARCADE);
	 
	  this.add.sprite(0, 0, 'sky');
	  
	  this.platforms = this.game.add.group();
	 
	  this.platforms.enableBody = true;
	  
	  var ground = this.platforms.create(0, this.game.world.height - 64, 'ground');
	  
	  ground.scale.setTo(2, 2);
	 
	  ground.body.immovable = true;
	  
	  var ledge = this.platforms.create(400, 400, 'ground');

	  ledge.body.immovable = true;

	  ledge = this.platforms.create(-150, 250, 'ground');

	  ledge.body.immovable = true;
	
	  this.player = this.game.add.sprite(32, this.game.world.height - 150, 'dude');

	  this.game.physics.arcade.enable(this.player);

	  this.player.body.bounce.y = 0.2;
	  this.player.body.gravity.y = 300;
	  this.player.body.collideWorldBounds = true;

	  this.player.animations.add('left', [0, 1, 2, 3], 10, true);
	  this.player.animations.add('right', [5, 6, 7, 8], 10, true);
	  
	  this.stars = this.game.add.group();

	  this.stars.enableBody = true;

	    //  Here we'll create 12 of them evenly spaced apart
	    for (var i = 0; i < 12; i++)
	    {
	        //  Create a star inside of the 'stars' group
	        var star = this.stars.create(i * 70, 0, 'star');

	        //  Let gravity do its thing
	        star.body.gravity.y = 6;

	        //  This just gives each star a slightly random bounce value
	        star.body.bounce.y = 0.7 + Math.random() * 0.2;
	    }
	    
	  cursors = this.game.input.keyboard.createCursorKeys();
};

Level.prototype.update = function() {
	// TODO: generated method.
	this.game.physics.arcade.collide(this.player, this.platforms);
	this.game.physics.arcade.collide(this.stars, this.platforms);
	
	this.game.physics.arcade.overlap(this.player, this.stars, collectStar, null, this);
	
	this.player.body.velocity.x = 0;

	    if (cursors.left.isDown)
	    {
	        //  Move to the left
	    	this.player.body.velocity.x = -150;

	    	this.player.animations.play('left');
	    }
	    else if (cursors.right.isDown)
	    {
	        //  Move to the right
	    	this.player.body.velocity.x = 150;

	        this.player.animations.play('right');
	    }
	    else
	    {
	        //  Stand still
	    	this.player.animations.stop();

	    	this.player.frame = 4;
	    }

	    //  Allow the player to jump if they are touching the ground.
	    if (cursors.up.isDown && this.player.body.touching.down)
	    {
	    	this.player.body.velocity.y = -350;
	    }
};

function collectStar (player, star) {

    // Removes the star from the screen
    star.kill();

}